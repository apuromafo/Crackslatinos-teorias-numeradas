#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @sasaga92
#Keygen canasta

_user = raw_input("ingrese nombre de usuario: ")

_table = [0x0d9,0x63,0x58,0x22,0x3e,0x93,0x0f0,0x08,0x34,0x62,0x1b,0x0bf,0x0d7,0x0b9,0x6f,0x4a,0x5a,0x0b2,0x84,0x24,0x11]

_cont_name = 1
_name_user = 0
if len(_user) > 0 and len(_user) <= 5:
	for _name in _user:
		_name_user += ord(_name)*_cont_name*_table[_cont_name-1]
		_cont_name += 1
		print _name_user
	if _user.isupper():
		print "USUARIO:",_user, "SERIAL: ",str(_name_user*2)
	else:
		print "USUARIO:",_user, "SERIAL: ",str(_name_user)
elif len(_user) > 5 and len(_user) <= 20:
	for _name in _user:
		_name_user += ord(_name)*_cont_name*_table[_cont_name-1]
		_cont_name += 1
	if len(str(_name_user)) > 6:
		print "USUARIO:",_user, "SERIAL: ",str(_name_user)[1:7]
	else:
		print "USUARIO:",_user, "SERIAL: ",str(_name_user)
else:
	print "EL KEYGEN NO GENERA SERIALES PARA SU CONDICION DE USUARIO"
