/*Feb-01-2008
Author: DCrack/FOFF
Code for public use, just greet the author if you're gonna use it*/
#include <windows.h> 
#define bytesSize 2

void terminateNCloseHandles(PROCESS_INFORMATION pi)
{
     TerminateProcess(pi.hProcess,0); 
     CloseHandle(pi.hProcess);
     CloseHandle(pi.hThread);
}
void main () 
{ 
     STARTUPINFO si; 
     PROCESS_INFORMATION pi; 
     char* cl;
     DWORD baseAddress=0x4010DF; 
     char originalBytes[bytesSize]={0x75,0x18}; 
     char newBytes[bytesSize]={0x90,0x90};
     char readBuffer[bytesSize]; 
     char fileName[]="Crackme1.exe"; 
     ZeroMemory (&si,sizeof(si)); 
     si.cb=sizeof(si); 
     cl=GetCommandLine(); 
     if (CreateProcess (&fileName,cl,NULL,NULL,FALSE,NORMAL_PRIORITY_CLASS, NULL,NULL,&si,&pi)) 
     { 
           WaitForInputIdle (pi.hProcess,INFINITE); 
           if (ReadProcessMemory (pi.hProcess,baseAddress,&readBuffer,bytesSize,NULL))
           { 
                int x = 0;
                while (readBuffer[x]==originalBytes[x] && x<bytesSize)
                {
                      x++;
                } 
                if (x==bytesSize)
                { 
                   if (!WriteProcessMemory (pi.hProcess,baseAddress,&newBytes,2,NULL))
                   {
                     terminateNCloseHandles(pi);
                     MessageBox(NULL,"Can't write bytes","Error",MB_OK|MB_ICONERROR); 
                     return;
                   }  
                } 
                else
                { 
                   terminateNCloseHandles(pi);
                   MessageBox(NULL,"Bytes don't match","Error",MB_OK|MB_ICONERROR);  
                   return;
                }
           }
           else 
           {
               terminateNCloseHandles(pi);
               MessageBox(NULL,"Can't ReadProcessMemory","Error",MB_OK|MB_ICONERROR); 
               return;
           }
           CloseHandle(pi.hProcess); 
           CloseHandle(pi.hThread); 
     } 
     else
      MessageBox(NULL,"Can't CreateProcess","Error",MB_OK|MB_ICONERROR);
}
