/*Feb-01-2008
Author: DCrack/FOFF
Code for public use, just greet the author if you're gonna use it*/
#include <windows.h> 
#define bytesSize 4
#define bytesSize2 1
void terminateNCloseHandles(PROCESS_INFORMATION pi)
{
     TerminateProcess(pi.hProcess,0); 
     CloseHandle(pi.hProcess);
     CloseHandle(pi.hThread);
}

void main () 
{ 
     STARTUPINFO si; 
     PROCESS_INFORMATION pi; 
     char* cl;
     DWORD memCheckBaseAddress=0x4072C8;
     char memCheckBytes[4]={0x01,0x00,0x00,0x00}; 
     DWORD baseAddress=0x401074;
     char originalBytes[bytesSize]={0x8B,0x4C,0x24,0x04}; 
     char newBytes[bytesSize]={0xC2,0x10,0x00,0x90};
     DWORD baseAddress2=0x401027;
     char originalBytes2[bytesSize2]={0x22}; 
     char newBytes2[bytesSize2]={0x6B};
     char readBuffer[bytesSize];
     char readBuffer2[bytesSize2];  
     char memCheckBytesBuffer[4];
     char fileName[]="KillNag.exe"; 
     ZeroMemory (&si,sizeof(si)); 
     si.cb=sizeof(si); 
     cl=GetCommandLine(); 
     if (CreateProcess (&fileName,cl,NULL,NULL,FALSE,CREATE_SUSPENDED, NULL,NULL,&si,&pi)) 
     { 
           int found = 0;
           long initialTime = GetTickCount();
           int x;
           while(!found)
           {
                 if ((GetTickCount() - initialTime) > 5000) //5 sec timeout
                 {
                    terminateNCloseHandles(pi);
                    MessageBox(NULL,"Never found the MemCheck bytes","Error",MB_OK|MB_ICONERROR);
                    return;
                 }
                 ResumeThread(pi.hThread);
                 ReadProcessMemory (pi.hProcess,memCheckBaseAddress,&memCheckBytesBuffer,4,NULL);
                 SuspendThread(pi.hThread);
                 x = 0;
                 while (memCheckBytesBuffer[x]==memCheckBytes[x] && x<4)
                 {
                      x++;
                 } 
                 if (x==4)
                 { 
                    found = 1;
                 } 
           }
           //Patch 1
           if (ReadProcessMemory (pi.hProcess,baseAddress,&readBuffer,bytesSize,NULL))
           { 
                x = 0;
                while (readBuffer[x]==originalBytes[x] && x<bytesSize)
                {
                      x++;
                } 
                if (x==bytesSize)
                { 
                   if (!WriteProcessMemory (pi.hProcess,baseAddress,&newBytes,bytesSize,NULL))
                   {
                      terminateNCloseHandles(pi);
                      MessageBox(NULL,"Can't write bytes","Error",MB_OK|MB_ICONERROR); 
                      return;
                   }
                } 
                else
                { 
                   terminateNCloseHandles(pi);
                   MessageBox(NULL,"Bytes don't match","Error",MB_OK|MB_ICONERROR);  
                   return;
                }
           }
           else
           { 
               terminateNCloseHandles(pi);
               MessageBox(NULL,"Can't ReadProcessMemory","Error",MB_OK|MB_ICONERROR);
               return;
           }
           //Patch 2
           if (ReadProcessMemory (pi.hProcess,baseAddress2,&readBuffer2,bytesSize2,NULL))
           { 
                x = 0;
                while (readBuffer2[x]==originalBytes2[x] && x<bytesSize2)
                {
                      x++;
                } 
                if (x==bytesSize2)
                { 
                   if (!WriteProcessMemory (pi.hProcess,baseAddress2,&newBytes2,bytesSize2,NULL))
                   {
                      terminateNCloseHandles(pi);
                      MessageBox(NULL,"Can't write bytes","Error",MB_OK|MB_ICONERROR); 
                      return;
                   }
                } 
                else
                { 
                   terminateNCloseHandles(pi);
                   MessageBox(NULL,"Bytes don't match","Error",MB_OK|MB_ICONERROR);  
                   return;
                }
           }
           else
           { 
               terminateNCloseHandles(pi);
               MessageBox(NULL,"Can't ReadProcessMemory","Error",MB_OK|MB_ICONERROR);
               return;
           }
           ResumeThread(pi.hThread); 
           CloseHandle(pi.hProcess); 
           CloseHandle(pi.hThread); 
     } 
     else
       MessageBox(NULL,"Can't CreateProcess","Error",MB_OK|MB_ICONERROR);
}
